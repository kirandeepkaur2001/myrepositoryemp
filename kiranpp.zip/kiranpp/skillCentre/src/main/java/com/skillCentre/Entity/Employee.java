package com.skillCentre.Entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table
@Entity
@Getter
@Setter
@NoArgsConstructor


public class Employee {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int EmployeeId;

    private String employeeName;
    private String designation;
    private String experience;
    private String primarySkills;
    private String knowledgeIn;
    private String additionalSkills;
    @Lob
    private byte[] resumeUpload;

}
