package com.skillCentre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillCentreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillCentreApplication.class, args);
	}

}
